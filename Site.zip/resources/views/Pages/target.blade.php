
<!--
<section class="success" id="about">
      <div class="container">
          <div class="row">
              <div class="col-lg-12 text-center">
                  <h3>Hosturkey's Target</h3>
                  <hr class="star-light">
              </div>
          </div>
          <div class="row">
              <div class="col-lg-4 col-lg-offset-2">
                  <p>Freelancer is a free bootstrap theme created by Start Bootstrap. The download includes the complete source files including HTML, CSS, and JavaScript as well as optional LESS stylesheets for easy customization.</p>
              </div>
              <div class="col-lg-4">
                  <p>Whether you're a student looking to showcase your work, a professional looking to attract clients, or a graphic artist looking to share your projects, this template is the perfect starting point!</p>
              </div>

          </div>
      </div>
  </section>
!-->
