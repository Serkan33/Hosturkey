
<footer>
    <div class="footer" id="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4  col-md-4 col-sm-4 col-xs-6 text-center">
                    <h3> HOSTURKEY </h3>
                    <ul>
                        <li> <a href="#">  +90-532-605-9060 </a> </li>
                        <li> <a href="#"> info@hosturkey.com </a> </li>

                    </ul>
                </div>

                <div class="col-lg-4  col-md-4 col-sm-4 col-xs-6 text-center">
                    <h3> SERVICES</h3>
                    <ul>
                        <li> <a href="#"> About Us </a> </li>
                        <li> <a href="#"> House For Sale </a> </li>
                        <li> <a href="#"> Contact </a> </li>

                    </ul>
                </div>

                <div class="col-lg-4  col-md-4 col-sm-6 col-xs-12 text-center">
                    <h3> SOCIAL LINKS </h3>

                    <ul class="social">
                        <li style="padding-top:8px"> <a href="#"> <i class=" fa fa-facebook">   </i> </a> </li>
                        <li style="padding-top:8px"> <a href="#"> <i class="fa fa-twitter">   </i> </a> </li>
                        <li style="padding-top:8px"> <a href="#"> <i class="fa fa-google-plus">   </i> </a> </li>
                        <li style="padding-top:8px"> <a href="#"> <i class="fa fa-linkedin">   </i> </a> </li>
                        <li style="padding-top:8px"> <a href="#"> <i class="fa fa-youtube">   </i> </a> </li>
                    </ul>
                </div>
            </div>
            <!--/.row-->
        </div>
        <!--/.container-->
    </div>
    <!--/.footer-->

    <div class="footer-bottom">
        <div class="container">
            <p class="pull-left" style="color:#000"> Copyright © Hosturkey 2016. </p>

            <div class="pull-right">
                <ul class="nav nav-pills payments">
                  <!--
                    <li><i class="fa fa-cc-visa"></i></li>
                    <li><i class="fa fa-cc-mastercard"></i></li>
                    <li><i class="fa fa-cc-amex"></i></li>
                    <li><i class="fa fa-cc-paypal"></i></li>
                    -->
                </ul>
            </div>
        </div>
    </div>
    <!--/.footer-bottom-->
</footer>
