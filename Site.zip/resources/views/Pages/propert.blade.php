
<div class="container-fluid ">
    <div class="row text-center">
        <h2 class="h2">Properties</h2>
    </div>
    <div class="container property-container">
            <div class="row">
                @for($i=0;$i<8;$i++)



                <div class="col-sm-4 col-md-3 ">
                    <div class="thumbnail golge">
                        <a href="">
                        <img src="https://cdn.pursuitist.com/wp-content/uploads/2013/08/Celine-Dion-puts-Jupiter-Island-estate-on-market-for-72.5-million-1152x759.jpg" alt="...">
                        <div class="h4 fiyat"> 358,584 TL</div> </a>
                        <div class="caption">
                           <h1 class="h4"> <small>Antalya,Konyaaltı</small></h1>
                            <h4 class="h5">Location</h4>

                        </div>
                        <ul class="list-inline" style="margin: 0">
                            <li class="glyphicon glyphicon-bed" title="Bed"> 05</li>
                            <li class="glyphicon glyphicon-apple"> 02</li>
                            <li class="glyphicon glyphicon-arrow-right"> 03</li>
                        </ul>
                    </div>
                </div>

    @endfor
            </div>

    </div>
</div>