<div class="row margin_space">

    <div class="container-fluid top-header">

        <ul>
            <li class="list-inline list-style"><a href=""> Register</a></li>
            <li class="list-inline list-style"> <a href="">Login</a></li>
            <div class=" header-social" >

              <li class="list-inline list-style list-loc"> <a href="https://tr.linkedin.com/in/hosturkey-hosturkey-399802127"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
            <li class="list-inline list-style list-loc"> <a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
            <li class="list-inline  list-style list-loc"><a href="https://www.facebook.com/hosturkey90/?fref=ts"> <i class="fa fa-facebook" aria-hidden="true"></i> </a></li>
            <li class="list-inline  list-style list-loc hidden-xs"><a href="tel://+90-532-605-9060"><i class="fa fa-phone" aria-hidden="true"> +90-532-605-9060</i></a></li>
            <li class="list-inline list-style list-loc hidden-xs"><a href="contact"><i class="fa fa-envelope" aria-hidden="true"> info@hosturkey.com</i></a></li>
            <li class="list-inline  list-style list-loc hidden-md hidden-lg"><a href=""><i class="fa fa-phone" aria-hidden="true"> </i></a></li>
          </div>
        </ul>
    </div>
</div>
