<div class="row margin_space">

    <div class="container-fluid top-header">

        <ul>
            <li class="list-inline list-style"><a href=""> Register</a></li>
            <li class="list-inline list-style"> <a href="">Login</a></li>
            <li class="list-inline  list-style list-loc"><a href=""> Register</a></li>
            <li class="list-inline list-style list-loc"> <a href="">Login</a></li>


        </ul>
    </div>
</div>

