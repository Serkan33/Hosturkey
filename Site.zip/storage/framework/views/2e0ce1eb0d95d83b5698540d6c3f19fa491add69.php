<table>
  <tr>
    <td>
      <strong>Ad:</strong>
    </td>
    <td>
        <?php echo e($name); ?>

    </td>
  </tr>
  <tr>
    <td>
      <strong>E-mail:</strong>
    </td>
    <td>
      <?php echo e($email); ?>

    </td>
  </tr>
  <tr>
    <td>
      <strong>Mobil:</strong>
    </td>
    <td>
      <?php echo e($mobil); ?>

    </td>
  </tr>
  <tr>
    <td>
      <strong>Mesaj:</strong>
    </td>
    <td>
      <?php echo e($bodymessage); ?>

    </td>
  </tr>
  <tr>
    <td>
      <strong>Ilan No:</strong>
    </td>
    <td>
      <?php echo e($ev_id); ?>

    </td>
  </tr>
</table>
