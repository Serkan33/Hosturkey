

<?php $__currentLoopData = $propert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($p->proprty_id); ?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



